$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/main/resources/feature/testcases.feature");
formatter.feature({
  "line": 2,
  "name": "Practice_Automation_Testing website",
  "description": "",
  "id": "practice-automation-testing-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Practice.AutomationTesting.in"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "Login in to the web application",
  "description": "",
  "id": "practice-automation-testing-website;login-in-to-the-web-application",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@TS_01_Login"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "open the url in a browser",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "url is launched click the MyAccount button",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "enter the email id and password in the excel sheet to register click login and assert",
  "keyword": "When "
});
formatter.match({
  "location": "Loginstepdefinition.open_the_url_in_a_browser()"
});
formatter.result({
  "duration": 40545902300,
  "status": "passed"
});
formatter.match({
  "location": "Loginstepdefinition.url_is_launched_click_the_MyAccount_button()"
});
formatter.result({
  "duration": 1438562200,
  "status": "passed"
});
formatter.match({
  "location": "Loginstepdefinition.enter_the_email_id_and_password_in_the_excel_sheet_to_register_click_login_and_assert()"
});
formatter.result({
  "duration": 52209907500,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "edit and save Billing Address",
  "description": "",
  "id": "practice-automation-testing-website;edit-and-save-billing-address",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 10,
      "name": "@TS_02_Edit_and_save_Billing_Address"
    }
  ]
});
formatter.step({
  "line": 12,
  "name": "open url in a browser07",
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "log in to practice web application",
  "keyword": "When "
});
formatter.step({
  "line": 14,
  "name": "click on the addresses",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "click edit billing address",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "fill the billing details",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "click save Addresses",
  "keyword": "When "
});
formatter.step({
  "line": 18,
  "name": "Assert Billing addresses changes successfully",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "07",
      "offset": 21
    }
  ],
  "location": "BillingAddressstepdefinition.open_url_in_a_browser(int)"
});
formatter.result({
  "duration": 23370188000,
  "status": "passed"
});
formatter.match({
  "location": "BillingAddressstepdefinition.log_in_to_practice_web_application()"
});
formatter.result({
  "duration": 5610488600,
  "status": "passed"
});
formatter.match({
  "location": "BillingAddressstepdefinition.click_on_the_addresses()"
});
formatter.result({
  "duration": 2436296200,
  "status": "passed"
});
formatter.match({
  "location": "BillingAddressstepdefinition.click_edit_billing_address()"
});
formatter.result({
  "duration": 28748130200,
  "error_message": "org.openqa.selenium.WebDriverException: java.net.ConnectException: Failed to connect to localhost/0:0:0:0:0:0:0:1:26662\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027DESKTOP-AQMRPTH\u0027, ip: \u0027192.168.55.104\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_60\u0027\nDriver info: driver.version: RemoteWebDriver\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:92)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:285)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.click(RemoteWebElement.java:84)\r\n\tat com.pages.EditBillingAddressPage.editBilling(EditBillingAddressPage.java:50)\r\n\tat com.stepdefinitions.BillingAddressstepdefinition.click_edit_billing_address(BillingAddressstepdefinition.java:30)\r\n\tat ✽.When click edit billing address(src/main/resources/feature/testcases.feature:15)\r\nCaused by: java.net.ConnectException: Failed to connect to localhost/0:0:0:0:0:0:0:1:26662\r\n\tat okhttp3.internal.connection.RealConnection.connectSocket(RealConnection.java:247)\r\n\tat okhttp3.internal.connection.RealConnection.connect(RealConnection.java:165)\r\n\tat okhttp3.internal.connection.StreamAllocation.findConnection(StreamAllocation.java:257)\r\n\tat okhttp3.internal.connection.StreamAllocation.findHealthyConnection(StreamAllocation.java:135)\r\n\tat okhttp3.internal.connection.StreamAllocation.newStream(StreamAllocation.java:114)\r\n\tat okhttp3.internal.connection.ConnectInterceptor.intercept(ConnectInterceptor.java:42)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:147)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:121)\r\n\tat okhttp3.internal.cache.CacheInterceptor.intercept(CacheInterceptor.java:93)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:147)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:121)\r\n\tat okhttp3.internal.http.BridgeInterceptor.intercept(BridgeInterceptor.java:93)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:147)\r\n\tat okhttp3.internal.http.RetryAndFollowUpInterceptor.intercept(RetryAndFollowUpInterceptor.java:126)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:147)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:121)\r\n\tat okhttp3.RealCall.getResponseWithInterceptorChain(RealCall.java:200)\r\n\tat okhttp3.RealCall.execute(RealCall.java:77)\r\n\tat org.openqa.selenium.remote.internal.OkHttpClient.execute(OkHttpClient.java:103)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:155)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:285)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.click(RemoteWebElement.java:84)\r\n\tat com.pages.EditBillingAddressPage.editBilling(EditBillingAddressPage.java:50)\r\n\tat com.stepdefinitions.BillingAddressstepdefinition.click_edit_billing_address(BillingAddressstepdefinition.java:30)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat cucumber.runtime.Utils$1.call(Utils.java:40)\r\n\tat cucumber.runtime.Timeout.timeout(Timeout.java:16)\r\n\tat cucumber.runtime.Utils.invoke(Utils.java:34)\r\n\tat cucumber.runtime.java.JavaStepDefinition.execute(JavaStepDefinition.java:38)\r\n\tat cucumber.runtime.StepDefinitionMatch.runStep(StepDefinitionMatch.java:37)\r\n\tat cucumber.runtime.Runtime.runStep(Runtime.java:300)\r\n\tat cucumber.runtime.model.StepContainer.runStep(StepContainer.java:44)\r\n\tat cucumber.runtime.model.StepContainer.runSteps(StepContainer.java:39)\r\n\tat cucumber.runtime.model.CucumberScenario.run(CucumberScenario.java:44)\r\n\tat cucumber.runtime.junit.ExecutionUnitRunner.run(ExecutionUnitRunner.java:102)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:63)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:18)\r\n\tat org.junit.runners.ParentRunner$4.run(ParentRunner.java:331)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:79)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:329)\r\n\tat org.junit.runners.ParentRunner.access$100(ParentRunner.java:66)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:293)\r\n\tat org.junit.runners.ParentRunner$3.evaluate(ParentRunner.java:306)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:413)\r\n\tat cucumber.runtime.junit.FeatureRunner.run(FeatureRunner.java:70)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:95)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:38)\r\n\tat org.junit.runners.ParentRunner$4.run(ParentRunner.java:331)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:79)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:329)\r\n\tat org.junit.runners.ParentRunner.access$100(ParentRunner.java:66)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:293)\r\n\tat org.junit.internal.runners.statements.RunAfters.evaluate(RunAfters.java:27)\r\n\tat org.junit.runners.ParentRunner$3.evaluate(ParentRunner.java:306)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:413)\r\n\tat cucumber.api.junit.Cucumber.run(Cucumber.java:100)\r\n\tat org.eclipse.jdt.internal.junit4.runner.JUnit4TestReference.run(JUnit4TestReference.java:89)\r\n\tat org.eclipse.jdt.internal.junit.runner.TestExecution.run(TestExecution.java:41)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:542)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:770)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.run(RemoteTestRunner.java:464)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.main(RemoteTestRunner.java:210)\r\nCaused by: java.net.ConnectException: Connection refused: connect\r\n\tat java.net.DualStackPlainSocketImpl.waitForConnect(Native Method)\r\n\tat java.net.DualStackPlainSocketImpl.socketConnect(Unknown Source)\r\n\tat java.net.AbstractPlainSocketImpl.doConnect(Unknown Source)\r\n\tat java.net.AbstractPlainSocketImpl.connectToAddress(Unknown Source)\r\n\tat java.net.AbstractPlainSocketImpl.connect(Unknown Source)\r\n\tat java.net.PlainSocketImpl.connect(Unknown Source)\r\n\tat java.net.SocksSocketImpl.connect(Unknown Source)\r\n\tat java.net.Socket.connect(Unknown Source)\r\n\tat okhttp3.internal.platform.Platform.connectSocket(Platform.java:129)\r\n\tat okhttp3.internal.connection.RealConnection.connectSocket(RealConnection.java:245)\r\n\t... 66 more\r\n",
  "status": "failed"
});
formatter.match({
  "location": "BillingAddressstepdefinition.fill_the_billing_details()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "BillingAddressstepdefinition.click_save_Addresses()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "BillingAddressstepdefinition.assert_Billing_addresses_changes_successfully()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 21,
  "name": "edit and save shipping addresses details",
  "description": "",
  "id": "practice-automation-testing-website;edit-and-save-shipping-addresses-details",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 20,
      "name": "@TS_03_Edit_and_Save_Shipping_Address"
    }
  ]
});
formatter.step({
  "line": 22,
  "name": "open url in a browser_08",
  "keyword": "Given "
});
formatter.step({
  "line": 23,
  "name": "login to the automation web application",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "click on the addresses tab",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "click on edit shipping addresses",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "fill the shipping details",
  "keyword": "When "
});
formatter.step({
  "line": 27,
  "name": "click on save addresses button",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "Assert shipping addresses changed successfully",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "08",
      "offset": 22
    }
  ],
  "location": "ShippingAddressstepdefinition.open_url_in_a_browser_(int)"
});
formatter.result({
  "duration": 18741414100,
  "status": "passed"
});
formatter.match({
  "location": "ShippingAddressstepdefinition.login_to_the_automation_web_application()"
});
formatter.result({
  "duration": 14663616900,
  "status": "passed"
});
formatter.match({
  "location": "ShippingAddressstepdefinition.click_on_the_addresses_tab()"
});
formatter.result({
  "duration": 2282060600,
  "status": "passed"
});
formatter.match({
  "location": "ShippingAddressstepdefinition.click_on_edit_shipping_addresses()"
});
formatter.result({
  "duration": 12759909900,
  "status": "passed"
});
formatter.match({
  "location": "ShippingAddressstepdefinition.fill_the_shipping_details()"
});
formatter.result({
  "duration": 7621742000,
  "status": "passed"
});
formatter.match({
  "location": "ShippingAddressstepdefinition.click_on_save_addresses_button()"
});
formatter.result({
  "duration": 17001012900,
  "status": "passed"
});
formatter.match({
  "location": "ShippingAddressstepdefinition.assert_shipping_addresses_changed_successfully()"
});
formatter.result({
  "duration": 1348626400,
  "error_message": "java.io.IOException: Destination \u0027C:\\Users\\Mahesh\\eclipse-workspace\\PracticeAutomationTesting2\\src\\test\\resources\\Screenshots\u0027 directory cannot be created\r\n\tat org.apache.commons.io.FileUtils.copyFile(FileUtils.java:1070)\r\n\tat org.apache.commons.io.FileUtils.copyFile(FileUtils.java:1028)\r\n\tat com.pages.EditShippingAddressPage.Screenshot(EditShippingAddressPage.java:83)\r\n\tat com.stepdefinitions.ShippingAddressstepdefinition.assert_shipping_addresses_changed_successfully(ShippingAddressstepdefinition.java:46)\r\n\tat ✽.Then Assert shipping addresses changed successfully(src/main/resources/feature/testcases.feature:28)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 31,
  "name": "Demosite - register",
  "description": "",
  "id": "practice-automation-testing-website;demosite---register",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 30,
      "name": "@TS_04_Demosite_Valid_Register"
    }
  ]
});
formatter.step({
  "line": 32,
  "name": "open the url in the browser06",
  "keyword": "Given "
});
formatter.step({
  "line": 33,
  "name": "login to the web application",
  "keyword": "When "
});
formatter.step({
  "line": 34,
  "name": "click demosite- register menu",
  "keyword": "When "
});
formatter.step({
  "line": 35,
  "name": "fill all the valid details",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "click submit button",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "Assert if it is move to next page",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "06",
      "offset": 27
    }
  ],
  "location": "DemoValidRegstepdefinition.open_the_url_in_the_browser(int)"
});
formatter.result({
  "duration": 36384674600,
  "status": "passed"
});
formatter.match({
  "location": "DemoValidRegstepdefinition.login_to_the_web_application()"
});
formatter.result({
  "duration": 14852370300,
  "status": "passed"
});
formatter.match({
  "location": "DemoValidRegstepdefinition.click_demosite_register_menu()"
});
formatter.result({
  "duration": 14987353500,
  "status": "passed"
});
formatter.match({
  "location": "DemoValidRegstepdefinition.fill_all_the_valid_details()"
});
formatter.result({
  "duration": 52542788300,
  "error_message": "org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"link text\",\"selector\":\"English\"}\n  (Session info: chrome\u003d80.0.3987.149)\nFor documentation on this error, please visit: https://www.seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027DESKTOP-AQMRPTH\u0027, ip: \u0027192.168.55.104\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_60\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 80.0.3987.149, chrome: {chromedriverVersion: 80.0.3987.106 (f68069574609..., userDataDir: C:\\Users\\DELL\\AppData\\Local...}, goog:chromeOptions: {debuggerAddress: localhost:53649}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify}\nSession ID: a93ced92bbdda376f89775573ada4a8b\n*** Element info: {Using\u003dlink text, value\u003dEnglish}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:323)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByLinkText(RemoteWebDriver.java:380)\r\n\tat org.openqa.selenium.By$ByLinkText.findElement(By.java:220)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\r\n\tat com.pages.DemoValidRegPage.fillValiddetails(DemoValidRegPage.java:68)\r\n\tat com.stepdefinitions.DemoValidRegstepdefinition.fill_all_the_valid_details(DemoValidRegstepdefinition.java:30)\r\n\tat ✽.When fill all the valid details(src/main/resources/feature/testcases.feature:35)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "DemoValidRegstepdefinition.click_submit_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "DemoValidRegstepdefinition.assert_if_it_is_move_to_next_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 41,
  "name": "Update details and chane password",
  "description": "",
  "id": "practice-automation-testing-website;update-details-and-chane-password",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 40,
      "name": "@TS_05_update_Account_Details"
    }
  ]
});
formatter.step({
  "line": 42,
  "name": "open the url in the browser_09",
  "keyword": "Given "
});
formatter.step({
  "line": 43,
  "name": "login with username and password to the web application",
  "keyword": "When "
});
formatter.step({
  "line": 44,
  "name": "click on the account details",
  "keyword": "When "
});
formatter.step({
  "line": 45,
  "name": "upadte details with new password",
  "keyword": "When "
});
formatter.step({
  "line": 46,
  "name": "click save changes button",
  "keyword": "When "
});
formatter.step({
  "line": 47,
  "name": "Assert account details changed successfully",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "09",
      "offset": 28
    }
  ],
  "location": "UpdatePasswordstepdefinition.open_the_url_in_the_browser_(int)"
});
formatter.result({
  "duration": 27454382300,
  "status": "passed"
});
formatter.match({
  "location": "UpdatePasswordstepdefinition.login_with_username_and_password_to_the_web_application()"
});
formatter.result({
  "duration": 9519144400,
  "status": "passed"
});
formatter.match({
  "location": "UpdatePasswordstepdefinition.click_on_the_account_details()"
});
formatter.result({
  "duration": 50186872200,
  "error_message": "org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"link text\",\"selector\":\"Account Details\"}\n  (Session info: chrome\u003d80.0.3987.149)\nFor documentation on this error, please visit: https://www.seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027DESKTOP-AQMRPTH\u0027, ip: \u0027192.168.55.104\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_60\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 80.0.3987.149, chrome: {chromedriverVersion: 80.0.3987.106 (f68069574609..., userDataDir: C:\\Users\\DELL\\AppData\\Local...}, goog:chromeOptions: {debuggerAddress: localhost:53891}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify}\nSession ID: fcec38f54aa77e715f5895f0f37e767c\n*** Element info: {Using\u003dlink text, value\u003dAccount Details}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:323)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByLinkText(RemoteWebDriver.java:380)\r\n\tat org.openqa.selenium.By$ByLinkText.findElement(By.java:220)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\r\n\tat com.pages.UpdatePasswordPage.clickAccountDetails(UpdatePasswordPage.java:46)\r\n\tat com.stepdefinitions.UpdatePasswordstepdefinition.click_on_the_account_details(UpdatePasswordstepdefinition.java:25)\r\n\tat ✽.When click on the account details(src/main/resources/feature/testcases.feature:44)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "UpdatePasswordstepdefinition.upadte_details_with_new_password()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "UpdatePasswordstepdefinition.click_save_changes_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "UpdatePasswordstepdefinition.assert_account_details_changed_successfully()"
});
formatter.result({
  "status": "skipped"
});
});