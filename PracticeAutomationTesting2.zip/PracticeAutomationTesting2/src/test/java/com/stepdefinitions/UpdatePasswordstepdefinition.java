package com.stepdefinitions;

import com.pages.UpdatePasswordPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UpdatePasswordstepdefinition {
	
	UpdatePasswordPage Upage = new UpdatePasswordPage();
	//To launch chrome browser
	@Given("^open the url in the browser_(\\d+)$")
	public void open_the_url_in_the_browser_(int arg1) {
		Upage.LaunchUrl("chrome");
	}
	//To login to the project automation application
	@When("^login with username and password to the web application$")
	public void login_with_username_and_password_to_the_web_application() {
		Upage.loginCredentials("rajasekhar4f2@gmail.com", "7013167813@mahesh");
	}
	//To check account details
	@When("^click on the account details$")
	public void click_on_the_account_details() {
		Upage.clickAccountDetails();
	}
	//To fill change password
	@When("^upadte details with new password$")
	public void upadte_details_with_new_password() throws Exception {
		Upage.fillChangePassword();
		Thread.sleep(300);
	}
	//To save changes
	@When("^click save changes button$")
	public void click_save_changes_button() {
		Upage.clickSaveChanges();
	}
	//Assert 
	@Then("^Assert account details changed successfully$")
	public void assert_account_details_changed_successfully() throws Exception {
		Upage.AssertChangePassword();
		Upage.Screenshot();
	}

}
