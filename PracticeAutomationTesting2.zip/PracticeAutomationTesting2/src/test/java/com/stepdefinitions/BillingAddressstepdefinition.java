package com.stepdefinitions;

import com.pages.EditBillingAddressPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BillingAddressstepdefinition {
	
	EditBillingAddressPage EBpage = new EditBillingAddressPage();
	//To launch chrome browser
	@Given("^open url in a browser(\\d+)$")
	public void open_url_in_a_browser(int arg1) {
		EBpage.LaunchUrl("chrome");
	}
	//To enter login credentials
	@When("^log in to practice web application$")
	public void log_in_to_practice_web_application() {
		EBpage.loginCredentials("rajasekhar4f2@gmail.com", "Raja@9177554637");
	}
	//To click on address
	@When("^click on the addresses$")
	public void click_on_the_addresses() {
		EBpage.clickAddresses();
	}
	//To edit billing address
	@When("^click edit billing address$")
	public void click_edit_billing_address() {
		EBpage.editBilling();
	}
	//To fill billing details
	@When("^fill the billing details$")
	public void fill_the_billing_details() {
		EBpage.fillDetails();
	}
	//To save address
	@When("^click save Addresses$")
	public void click_save_Addresses() {
	   EBpage.clickSaveAddresses();
	}
	//Assert
	@Then("^Assert Billing addresses changes successfully$")
	public void assert_Billing_addresses_changes_successfully() throws Exception {
		EBpage.AssertBilling();
		EBpage.Screenshot();
	}


}
