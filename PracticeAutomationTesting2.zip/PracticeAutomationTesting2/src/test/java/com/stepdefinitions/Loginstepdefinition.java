package com.stepdefinitions;

import com.pages.LoginFromExcelPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Loginstepdefinition {

	LoginFromExcelPage page = new LoginFromExcelPage();

	// To launch chrome browser
	@Given("^open the url in a browser$")
	public void open_the_url_in_a_browser() {
		page.LaunchUrl("chrome");

	}

	// To click on my account
	@When("^url is launched click the MyAccount button$")
	public void url_is_launched_click_the_MyAccount_button() {
		page.clickMyAccount();
	}

	// To enter login credentials andlogout
	@When("^enter the email id and password in the excel sheet click login and assert$")
	public void enter_the_email_id_and_password_in_the_excel_sheet_click_login_and_assert() throws Throwable {
		
		  page.loginCredentials(1); 
		  page.clickLogin(); 
		  page.Assert();
		  page.Screenshot1();
		  page.logout();
		 
		/*
		 * for (int i = 1; i <= 3; i++) { page.loginCredentials(i); page.clickLogin();
		 * page.Assert(); if (i == 1) page.Screenshot1(); else if (i == 2)
		 * page.Screenshot2(); else page.Screenshot3(); page.logout(); }
		 */
	}

	@Then("^close the browser$")
	public void close_the_browser() throws Throwable {
		page.quit();
	}

}
