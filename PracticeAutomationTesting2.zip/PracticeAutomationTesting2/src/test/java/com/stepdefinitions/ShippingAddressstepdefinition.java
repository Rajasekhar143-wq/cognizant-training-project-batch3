package com.stepdefinitions;

import com.pages.EditShippingAddressPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ShippingAddressstepdefinition {
	
	EditShippingAddressPage ESpage = new EditShippingAddressPage();
	//To launch chrome browser
	@Given("^open url in a browser_(\\d+)$")
	public void open_url_in_a_browser_(int arg1) {
		ESpage.LaunchUrl("chrome");
	}
	//To enter login credentials
	@When("^login to the automation web application$")
	public void login_to_the_automation_web_application() {
		ESpage.loginCredentials("rajasekhar4f2@gmail.com", "Raja@9177554637");
	}
	//To click on address
	@When("^click on the addresses tab$")
	public void click_on_the_addresses_tab() {
		ESpage.clickAddresses();
	}
	//To edit shipping address
	@When("^click on edit shipping addresses$")
	public void click_on_edit_shipping_addresses() {
		ESpage.editShipping();
	}
	//To fill shipping details
	@When("^fill the shipping details$")
	public void fill_the_shipping_details() {
		ESpage.fillShippingDetails();
	}
	//To save address
	@When("^click on save addresses button$")
	public void click_on_save_addresses_button() {
		ESpage.clickSaveAddress();
	}
	//Assert
	@Then("^Assert shipping addresses changed successfully$")
	public void assert_shipping_addresses_changed_successfully() throws Exception {
		ESpage.AssertShipping();
		ESpage.Screenshot();
	}


}
