package com.pages;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class EditBillingAddressPage {
	WebDriver driver;
	public void LaunchUrl(String browser) {
		//To launch chrome browser
		if(browser.equalsIgnoreCase("chrome"))
		{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Downloads\\PracticeAutomationTesting2\\src\\test\\resources\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		}
		//To launch firefox browser
				else if(browser.equalsIgnoreCase("firefox"))
				{
					System.setProperty("webdriver.geckodriver.driver","C:\\Users\\DELL\\Downloads\\anusha\\src\\test\\resources\\driver\\geckodriver.exe");
					driver = new FirefoxDriver();
				}
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.get("http://practice.automationtesting.in/");
		System.out.println(driver.getTitle());
	}
	//To enter login credentials
	public void loginCredentials(String user, String password) {
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.id("username")).sendKeys(user);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.xpath("//input[@name='login']")).click();
	}
	//To click on address
	public void clickAddresses() {
		driver.findElement(By.linkText("Addresses")).click();
	}
	//To edit billing address
	public void editBilling() {
		driver.findElement(By.xpath("//*[@id=\"page-36\"]/div/div[1]/div/div/div[1]/header/a")).click();
	}
	//To fill billing details
	public void fillDetails() {
		driver.findElement(By.id("billing_first_name")).clear();
		driver.findElement(By.id("billing_first_name")).sendKeys("Raja");
		driver.findElement(By.id("billing_last_name")).clear();
		driver.findElement(By.id("billing_last_name")).sendKeys("sekhar");
		driver.findElement(By.id("billing_company")).clear();
		driver.findElement(By.id("billing_company")).sendKeys("cts");
		driver.findElement(By.id("billing_phone")).clear();
		driver.findElement(By.id("billing_phone")).sendKeys("2587413690");
		driver.findElement(By.id("billing_address_1")).clear();
		driver.findElement(By.id("billing_address_1")).sendKeys("45-ht/630");
		driver.findElement(By.id("billing_address_2")).clear();
		driver.findElement(By.id("billing_address_2")).sendKeys("Balanagar");
		driver.findElement(By.id("billing_city")).clear();
		driver.findElement(By.id("billing_city")).sendKeys("Hyderabad");
		driver.findElement(By.id("billing_postcode")).clear();
		driver.findElement(By.id("billing_postcode")).sendKeys("456789");
	}
	//To save address
	public void clickSaveAddresses() {
		driver.findElement(By.xpath("//input[@type='submit']")).click();
	}
	//Assert
	public void AssertBilling() {
		String a = driver.findElement(By.xpath("//div[@class='woocommerce-message']")).getText();
		Assert.assertEquals("Address changed successfully.",a);
		System.out.println("Billing saved Successfully");
	}
	//To take screenshot
	public void Screenshot() throws Exception {
		TakesScreenshot ts= (TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source,new File("C:\\Users\\Mahesh\\eclipse-workspace\\PracticeAutomationTesting2\\src\\test\\resources\\Screenshots\\Billingaddress.png"));
	}
	
}
