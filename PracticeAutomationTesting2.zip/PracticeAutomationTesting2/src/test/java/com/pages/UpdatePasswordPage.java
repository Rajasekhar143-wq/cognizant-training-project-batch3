package com.pages;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class UpdatePasswordPage {
	WebDriver driver;
	public void LaunchUrl(String browser) {
		//To launch chrome browser
		if(browser.equalsIgnoreCase("chrome"))
		{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Downloads\\PracticeAutomationTesting2\\src\\test\\resources\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		}
		//To launch firefox browser
				else if(browser.equalsIgnoreCase("firefox"))
				{
					System.setProperty("webdriver.geckodriver.driver","C:\\Users\\DELL\\Downloads\\anusha\\src\\test\\resources\\driver\\geckodriver.exe");
					driver = new FirefoxDriver();
				}
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.get("http://practice.automationtesting.in/");
		System.out.println(driver.getTitle());
	}
	//To login to the project automation application
	public void loginCredentials(String user, String password) {
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.id("username")).sendKeys(user);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.xpath("//input[@name='login']")).click();
	}
	//To check account details
	public void clickAccountDetails() {
		driver.findElement(By.linkText("Account Details")).click();
	}
	//To fill change password
	public void fillChangePassword() {
		driver.findElement(By.id("account_first_name")).clear();
		driver.findElement(By.id("account_first_name")).sendKeys("Mahesh");
		driver.findElement(By.id("account_last_name")).clear();
		driver.findElement(By.id("account_last_name")).sendKeys("Raj");
		driver.findElement(By.id("password_current")).sendKeys("7013167813@mahesh");
		driver.findElement(By.id("password_1")).sendKeys("Raja@9177554637");
		driver.findElement(By.id("password_2")).sendKeys("Raja@9177554637");
		
	}
	//To save changes
	public void clickSaveChanges() {
		driver.findElement(By.name("save_account_details")).click();
	}
	//Assert 
	public void AssertChangePassword() {
		String a = driver.findElement(By.xpath("//div[@class='woocommerce-message']")).getText();
		Assert.assertEquals("Account details changed successfully.",a);
		System.out.println("Account details changed Successfully");
	}
	//To take screenshot
	public void Screenshot() throws Exception {
		TakesScreenshot ts= (TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source,new File("C:\\Users\\Mahesh\\eclipse-workspace\\PracticeAutomationTesting2\\src\\test\\resources\\Screenshots\\PasswordUpdated.png"));
	}
}
