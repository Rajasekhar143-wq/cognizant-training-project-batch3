package com.pages;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class DemoValidRegPage {

	WebDriver driver;
	public void LaunchUrl(String browser) {
		//To launch chrome browser
		if(browser.equalsIgnoreCase("chrome"))
		{
		System.setProperty("webdriver.chrome.driver","src\\test\\resources\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		}
		//To launch internetExplorer browser
		else if(browser.equalsIgnoreCase("Explorer"))
		{
			System.setProperty("webdriver.ie.driver","src\\test\\resources\\Drivers\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.get("http://practice.automationtesting.in/");
		System.out.println(driver.getTitle());
	}

	//To click on demosite
	public void ClickDemosite() {
		driver.findElement(By.linkText("Demo Site")).click();
		//driver.findElement(By.linkText("Register")).click();
	}
	//To fill valid details
	public void fillValiddetails() throws Exception {
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("Mahesh");
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("raj");
		driver.findElement(By.xpath("//textarea[@ng-model='Adress']")).sendKeys("A R nagar,nagole");
		driver.findElement(By.xpath("//input[@ng-model='EmailAdress']")).sendKeys("Rajasekhar@gmail.com");
		List<WebElement> rb = driver.findElements(By.xpath("//input[@value='Male']"));
		((WebElement) rb.get(0)).click();
		driver.findElement(By.xpath("//input[@ng-model='Phone']")).sendKeys("7894561237");
		driver.findElement(By.id("checkbox1")).click();
		driver.findElement(By.id("checkbox3")).click();
		  driver.findElement(By.xpath("//div[@style='min-height:30px;max-width:200px']")).click(); 
		  driver.findElement(By.linkText("English")).click();
		WebElement we1 = driver.findElement(By.id("Skills"));
		Select se1= new Select(we1);
		se1.selectByVisibleText("C");
		driver.findElement(By.xpath("//select[@type='text']")).click();
		driver.findElement(By.xpath("//option[@value='India']")).click();
		/*
		 * driver.findElement(By.xpath("//span[@role='combobox']")).click();
		 * driver.findElement(By.xpath("//input[@tabindex='0']")).sendKeys("India");
		 * driver.findElement(By.xpath("//span[@title='India']")).sendKeys(Keys.ENTER);
		 */
		  driver.findElement(By.xpath("//span[@class='select2-selection select2-selection--single']")).click();
		  driver.findElement(By.xpath("//input[@type='search']")).click();
		  driver.findElement(By.xpath("//input[@type='search']")).sendKeys("India");
		  Actions act = new Actions(driver); 
		  Thread.sleep(30);
		  act.sendKeys(Keys.ENTER);
		WebElement we6 = driver.findElement(By.id("yearbox"));
		Select se6= new Select(we6);
		se6.selectByVisibleText("1997");
		
		WebElement we4 = driver.findElement(By.xpath("//select[@placeholder='Month']"));
		Select se4 = new Select(we4);
		se4.selectByVisibleText("June");
		WebElement we5 = driver.findElement(By.id("daybox"));
		Select se5 = new Select(we5);
		se5.selectByVisibleText("22");
		driver.findElement(By.id("firstpassword")).sendKeys("1233456789@Mah");
		driver.findElement(By.id("secondpassword")).sendKeys("1233456789@Mah");
		WebElement uploadElement = driver.findElement(By.xpath("//input[@type='file']"));
		uploadElement.sendKeys("C:\\Users\\Mahesh\\Pictures\\Screenshots\\New folder\\Screenshot (9).png");

	}
	//To click on submit
	public void clickSubmit() {
		driver.findElement(By.xpath("//button[@value='sign up']")).click();
	}
	//Assert
	public void AssertValidreg() {
		String b = driver.findElement(By.xpath("/html/body/section/div[1]/div/div[2]/h4[1]/b")).getText();
		//Assert.assertEquals(" - Double Click on Edit Icon to ",b);
		System.out.println(b);
		System.out.println("submitted Successfully");
	}
	//To take screenshot
	public void Screenshot() throws Exception {
		TakesScreenshot ts= (TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source,new File("src\\test\\resources\\Screenshots\\DemovalidReg.png"));
	}
	//To close the browser window
		public void quit() {
			driver.close();
		}
	
}
