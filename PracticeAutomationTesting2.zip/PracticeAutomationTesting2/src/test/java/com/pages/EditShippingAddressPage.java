package com.pages;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class EditShippingAddressPage {
	WebDriver driver;
	public void LaunchUrl(String browser) {
		//To launch chrome browser
		if(browser.equalsIgnoreCase("chrome"))
		{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Downloads\\PracticeAutomationTesting2\\src\\test\\resources\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		}
		//To launch firefox browser
				else if(browser.equalsIgnoreCase("firefox"))
				{
					System.setProperty("webdriver.geckodriver.driver","C:\\Users\\DELL\\Downloads\\anusha\\src\\test\\resources\\driver\\geckodriver.exe");
					driver = new FirefoxDriver();
				}
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.get("http://practice.automationtesting.in/");
		System.out.println(driver.getTitle());
	}
	//To enter login credentials
	public void loginCredentials(String user, String password) {
		driver.findElement(By.linkText("My Account")).click();
		driver.findElement(By.id("username")).sendKeys(user);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.xpath("//input[@name='login']")).click();
	}
	//To click on address
	public void clickAddresses() {
		driver.findElement(By.linkText("Addresses")).click();
	}
	//To edit shipping address
	public void editShipping() {
		driver.findElement(By.xpath("//*[@id=\"page-36\"]/div/div[1]/div/div/div[2]/header/a")).click();
	}
	//To fill shipping details
	public void fillShippingDetails() {
		driver.findElement(By.id("shipping_first_name")).clear();
		driver.findElement(By.id("shipping_first_name")).sendKeys("Mahesh");
		driver.findElement(By.id("shipping_last_name")).clear();
		driver.findElement(By.id("shipping_last_name")).sendKeys("Raj");
		driver.findElement(By.id("shipping_company")).clear();
		driver.findElement(By.id("shipping_company")).sendKeys("cts");
		driver.findElement(By.id("shipping_address_1")).clear();
		driver.findElement(By.id("shipping_address_1")).sendKeys("784-fg-230");
		driver.findElement(By.id("shipping_address_2")).clear();
		driver.findElement(By.id("shipping_address_2")).sendKeys("peer nagar");
		driver.findElement(By.id("shipping_city")).clear();
		driver.findElement(By.id("shipping_city")).sendKeys("Hyderabad");
		driver.findElement(By.id("shipping_postcode")).clear();
		driver.findElement(By.id("shipping_postcode")).sendKeys("456213");
	}
	//To save address
	public void clickSaveAddress() {
		driver.findElement(By.name("save_address")).click();
	}
	//Assert
	public void AssertShipping() {
		String a = driver.findElement(By.xpath("//div[@class='woocommerce-message']")).getText();
		Assert.assertEquals("Address changed successfully.",a);
		System.out.println("Shipping saved Successfully");
	}
	//To take screenshot
	public void Screenshot() throws Exception {
		TakesScreenshot ts= (TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source,new File("C:\\Users\\Mahesh\\eclipse-workspace\\PracticeAutomationTesting2\\src\\test\\resources\\Screenshots\\ShippingAddress.png"));
	}
}
