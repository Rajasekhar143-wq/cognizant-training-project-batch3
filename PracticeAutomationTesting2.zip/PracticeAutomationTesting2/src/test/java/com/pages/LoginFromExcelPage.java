package com.pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.ExcelUtility.ExcelRead;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;

public class LoginFromExcelPage {
	WebDriver driver;
	public void LaunchUrl(String browser) {
		//To launch chrome browser
		if(browser.equalsIgnoreCase("chrome"))
		{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Downloads\\PracticeAutomationTesting2\\src\\test\\resources\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		}
		//To launch firefox browser
				else if(browser.equalsIgnoreCase("firefox"))
				{
					System.setProperty("webdriver.geckodriver.driver","C:\\Users\\DELL\\Downloads\\anusha\\src\\test\\resources\\driver\\geckodriver.exe");
					driver = new FirefoxDriver();
				}
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.get("http://practice.automationtesting.in/");
		System.out.println(driver.getTitle());
	}
	//To click on my account
	public void clickMyAccount() {
		driver.findElement(By.linkText("My Account")).click();
	}
	//To enter login credentials
	public void loginCredentials(int i) throws Exception {
		ExcelRead da = new ExcelRead();
		driver.findElement(By.id("username")).sendKeys(da.excel_username(i));
		driver.findElement(By.id("password")).sendKeys(da.excel_password(i));
	}
	//To click on login
	public void clickLogin() {
		driver.findElement(By.xpath("//input[@name='login']")).click();
	}
	//Assert
	public void Assert() throws Exception {
		String a = driver.findElement(By.linkText("Dashboard")).getText();
		Assert.assertEquals("Dashboard",a);
		System.out.println("Logged Successfully");
	}
	//Logout from the application
	public void logout() {
		driver.findElement(By.xpath("//*[@id=\"page-36\"]/div/div[1]/div/p[1]/a")).click();
	}
	//To take screenshots
	public void Screenshot1() throws Exception {
		TakesScreenshot ts= (TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source,new File("C:\\Users\\DELL\\Downloads\\PracticeAutomationTesting2\\src\\test\\resources\\Screenshots\\Loggedin1.png"));
	}
	public void Screenshot2() throws Exception {
		TakesScreenshot ts= (TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source,new File("C:\\Users\\DELL\\Downloads\\PracticeAutomationTesting2\\src\\test\\resources\\Screenshots\\Loggedin2.png"));
	}
	public void Screenshot3() throws Exception {
		TakesScreenshot ts= (TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source,new File("C:\\Users\\DELL\\Downloads\\PracticeAutomationTesting2\\src\\test\\resources\\Screenshots\\Loggedin3.png"));
	}
}
