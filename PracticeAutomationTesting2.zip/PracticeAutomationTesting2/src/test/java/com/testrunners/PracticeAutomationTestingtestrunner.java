package com.testrunners;

import org.junit.runner.RunWith;


import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
features = "src\\main\\resources\\feature\\testcases.feature",
plugin = {"pretty:target/json-report.json","html:target/cucumber-html-report","junit:target/junit-xml-report.xml","com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html"},
tags = {"@TS_01_Login,@TS_02_Edit_and_save_Billing_Address,@TS_03_Edit_and_Save_Shipping_Address,@TS_04_Demosite_Valid_Register,@TS_05_update_Account_Details"},
glue = {"com/stepdefinitions"},
monochrome = true
)

public class PracticeAutomationTestingtestrunner {

}
